import moment from "moment";
import { Parser } from "./parsers/parser.interface";

class TimestampParse implements Parser {
    execute(value: string): string {
        return value == null ? null : moment(value).format();
    }
} 

export default new TimestampParse();
