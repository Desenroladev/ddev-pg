export interface Parser {
    execute(value: string): string;
}
