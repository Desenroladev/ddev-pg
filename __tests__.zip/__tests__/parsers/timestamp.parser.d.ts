import { Parser } from "./parsers/parser.interface";
declare class TimestampParse implements Parser {
    execute(value: string): string;
}
declare const _default: TimestampParse;
export default _default;
