"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var moment_1 = __importDefault(require("moment"));
var TimestampParse = /** @class */ (function () {
    function TimestampParse() {
    }
    TimestampParse.prototype.execute = function (value) {
        return value == null ? null : moment_1.default(value).format();
    };
    return TimestampParse;
}());
exports.default = new TimestampParse();
