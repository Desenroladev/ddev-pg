"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var moment_1 = __importDefault(require("moment"));
var TimestampTzParse = /** @class */ (function () {
    function TimestampTzParse() {
    }
    TimestampTzParse.prototype.execute = function (value) {
        if (!value) {
            return null;
        }
        if (!([19, 22, 25].includes(value.length))) {
            throw new Error("Timestamp invalid format. Exemple valid format: 2001-07-03T01:34:17-00:00");
        }
        return moment_1.default(value).format();
    };
    return TimestampTzParse;
}());
exports.default = new TimestampTzParse();
