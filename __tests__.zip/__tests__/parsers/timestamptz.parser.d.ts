import { Parser } from "./parsers/parser.interface";
declare class TimestampTzParse implements Parser {
    execute(value: string): string;
}
declare const _default: TimestampTzParse;
export default _default;
