import { Connection, Database } from "../src";

describe('Testing Database Connection > ', () => {
    test('findAll records', async () => {
        const sql = `select 
                        id, 
                        title, 
                        created_at,
                        concluded,
                        concluded_at
                    from todo`;

        const db = new Database();
        const rows = await db.query(sql);

        console.log(rows);
    });
  
    test('insert record', async() => {
        const db = new Database();
        let connection: Connection = null;
        try {
            connection = await db.transaction();
            const binds = [
                'Teste Automatizado',
                '2001-07-03T01:34:17'
            ];
            const sql = `insert into todo(title, concluded_at) values($1, $2) returning *`;
            const res = await connection.execute(sql, binds);
            await connection.commit();
        } catch(err) {
            if(connection) {
                await connection.rollback();
            }
            throw err;
        }
    });
});